      common /cstate/ to(km), so(km), c(km,9)
