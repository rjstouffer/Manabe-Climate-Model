c====================== include file "versno.h" ========================
c
      character*80 model
      common /versno/ model
c
