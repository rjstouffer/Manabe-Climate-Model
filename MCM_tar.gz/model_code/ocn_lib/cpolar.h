c====================== include file "cpolar.h" =========================
c
c     polar transform coefficients used to transform velocities near 
c     poles before filtering
c
      common /cpolar/ spsin(imt), spcos(imt)
c
