c====================== include file "ndcon.h" ========================
c
c     various non dimensional quantities:
c
c     radian = degrees per radian
c     pi     = something good to eat
c
      common /ndcon/ radian, pi
c
