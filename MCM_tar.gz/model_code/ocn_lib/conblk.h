c====================== include file "conblk.h" =========================
c
      common / conblk / konblk(100)
c
