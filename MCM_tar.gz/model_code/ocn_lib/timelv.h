c====================== include file "timelv.h" ========================
c
c     time level pointers (indices) for the memory slab window
c
c     nm = time level pointer (index) corresponding to "tau-1"
c     nc = time level pointer (index) corresponding to "tau"
c     np = time level pointer (index) corresponding to "tau+1"
c
c
      common /ctlevp/ nm, nc, np
c
