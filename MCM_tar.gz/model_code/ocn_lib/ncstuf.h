      integer ncid, sdsk_id

      common / ncstuf / ncid, sdsk_id
