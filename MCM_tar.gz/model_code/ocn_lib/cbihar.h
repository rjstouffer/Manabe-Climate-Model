c====================== include file "cbihar.h" ========================
#ifndef multitasking
# define task
#endif
c
c     del**2 of prognostic variables
c
cSGI
      task common /cbihar/ del2(imt,km,nvarbh,numjpt)
           common /cbihar/ del2(imt,km,nvarbh,numjpt)
c
