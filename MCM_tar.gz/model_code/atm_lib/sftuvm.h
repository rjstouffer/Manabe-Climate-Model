      common / sftuvm / ucosm(mx,jx,kx), vcosm(mx,jx,kx)
