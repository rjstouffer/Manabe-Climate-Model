      common / anal1  / toan(12),ycean(12),qoan(12)
      common / anal1  / swan(12),rlwan(12),taan(12),snoan(12)
#if defined cpldleg3 || defined cpldleg1
      common / anal1  / pmean(12)
#endif
