#ifdef dirnal
      integer adski, adsko
      integer bdski, bdsko
c
      common / dirstr / adski, adsko
      common / dirstr / bdski, bdsko
#endif
