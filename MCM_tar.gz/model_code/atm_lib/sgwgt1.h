      common / sigwgt / q     (kx), dq    (kx), qmh(0:kx), factr (kx)
      common / sigwgt / odq   (kx), akapsg(kx), extkx    , extkxm
      common / sigwgt / dqmqa5(km), dqph  (km), den  (km), den1  (km)
      common / sigwgt / den2  (km), pq    (km), factq(kx), dqi   (km)
      common / sigwgt / gg    (kx), vrt2  (km), qlgc3(kx), qlgc4 (kx)
      common / sigwgt / vrt4  (km)
