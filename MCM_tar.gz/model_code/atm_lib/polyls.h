      common / polyls / poly(mx , jx), polydx(mx,jx), polydy(mx,jx)
      common / polyls / epsi(mxp,jxp)
