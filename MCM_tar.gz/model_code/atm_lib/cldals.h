       common / cldals / zza(lx,2)
