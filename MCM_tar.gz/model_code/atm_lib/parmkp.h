c
      parameter ( kp = kx + 1, km = kx - 1 )
c

