cSGI
      real*4 alb
cSGI
      common / albedo / alb(ix,il)
