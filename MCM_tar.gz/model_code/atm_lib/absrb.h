      common / absrb  / absrb(31,7,2), ao3(25), adc(3), bad(3), ok(3)
      common / absrb  / pplog(7)
