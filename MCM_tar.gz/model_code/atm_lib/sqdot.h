#ifdef dirnal
      common / sqdot  / qdot  (mx,jx,kx),  somg(mx,jx,kx)
      common / sqdot  / gwdots(ix,kx,nhem)
#endif
