      common / lincoef / elcf(mx,jx), vxy(mx,jx), txy(mx,jx)
      common / lincoef /  qxy(mx,jx)
