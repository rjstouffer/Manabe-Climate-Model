c====================== include file "cexpnam.h" ========================
c
c     Load the experiment name with the name read 
c      in program airsea
c
      character*8 expn1, expn2
      common / expname / expn1, expn2
c
