      common / mrstr  / irt, irtsav
