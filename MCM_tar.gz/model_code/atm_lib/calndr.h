      common / calndr  / dy(13)
