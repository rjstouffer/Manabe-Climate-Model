      common / water  / qmix (mx,jx,kx), qmixm(mx,jx,kx)
      common / water  / qmxdt(mx,jx,kx)
