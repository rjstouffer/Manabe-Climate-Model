c
      parameter ( jv= 26, ndt= 31, lnd= 2 )
      parameter ( nb= 19, ng= 3, ngp= ng + 1)
c
