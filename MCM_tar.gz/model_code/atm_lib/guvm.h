      common / guvm  / gucosm (ix,kx,nhem), gvcosm (ix,kx,nhem)
      common / guvm  / gtm    (ix,kx,nhem)
#ifdef moist
      common / guvm  / gqmixm (ix,kx,nhem)
#endif
