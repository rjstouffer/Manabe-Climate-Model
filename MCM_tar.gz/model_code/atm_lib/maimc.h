      common / maim   / rco2, r(0:kp,ng), p(0:kp), pp(0:kx)
