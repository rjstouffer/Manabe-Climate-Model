c
c ocean currents from second layer of ocean model
c
#ifdef icecpld
      common / ascomi / biceo(imt,jmt,2)
#endif
