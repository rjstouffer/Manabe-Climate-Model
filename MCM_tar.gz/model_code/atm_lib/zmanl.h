      common / zmanl / zmto(il), zmyce(il)
      common / zmanl / zmqo(il), zmsno(il)
