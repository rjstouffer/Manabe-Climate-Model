c
      common / rhcrit / hcrit(kx,il)
c
c  hcrit is the critical relative humidity for cloud formation
c        the test is equal to or greater than
c
