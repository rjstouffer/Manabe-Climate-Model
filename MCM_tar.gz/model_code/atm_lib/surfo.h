      common / surfo / yce(ix,il)
      common / surfo / to (ix,il)
