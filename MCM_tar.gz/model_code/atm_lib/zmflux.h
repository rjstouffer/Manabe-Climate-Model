      common / zmflux / zmsnht(il), zmltht(il)
      common / zmflux / zmqao (il)
#ifdef rad
      common / zmflux / zmswtp(il), zmswbm(il)
      common / zmflux / zmlwtp(il), zmlwbm(il)
#endif
#ifdef prdcld
      common / zmflux / zmtcld(il)
#endif
