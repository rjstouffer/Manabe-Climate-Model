      common / sstcof / cosbf , sinbf , cos2bf, cosfeb, sinfeb, cos2fb
      common / sstcof / cosaug, sinaug, cos2ag
