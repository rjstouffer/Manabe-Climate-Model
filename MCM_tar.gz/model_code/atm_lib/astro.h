      common / astro  / alp, dlt, fjd, rvct, slag
      common / astro  / alat(il), ha(il), xlat(il)
      common / astro  / jld
