      common / cld    / kbh(lx), kth(lx), cldlw(lx), cldsw(lx)
#ifdef prdcld
      common / cld    / ccover(ix,0:kp)
#endif
