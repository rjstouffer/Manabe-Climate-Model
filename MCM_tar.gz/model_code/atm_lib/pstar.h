      common / pstar / ps   (mx,jx,1)
