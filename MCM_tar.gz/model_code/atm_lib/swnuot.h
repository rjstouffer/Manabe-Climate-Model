      common / swnuot / flx(kp), heat(kp), grdflx
