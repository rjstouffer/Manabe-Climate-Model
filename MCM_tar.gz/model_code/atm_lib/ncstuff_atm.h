* netCDF id
      integer  ncid72, ncid71
* variable ids
      integer  lon_id
      integer  lat_id

      common / ncstuf2 / ncid72, lon_id, lat_id
      common / ncstuf2 / ncid71
      common / ncstuf2 / klevid, mwavid, nwavid
      common / ncstuf2 / klvpid
      common / ncstuf2 / idvor , iddiv , idtemp
      common / ncstuf2 / idpsln, idqmix
      common / ncstuf2 / idvorm, iddivm, idtmpm
      common / ncstuf2 / idpsm , idqmxm
      common / ncstuf2 / idzs  , idrdtn, idswdp
      common / ncstuf2 / idts  , idprcp, idevpr
      common / ncstuf2 / idsnfl, idsolm, idrunf
      common / ncstuf2 / idsndp, idsnml, idcalb
      common / ncstuf2 / idsubl, idycmt, idkflg
      common / ncstuf2 / idtmsr, idtmn
      common / ncstuf2 / idqao , idtaux, idtauy
      common / ncstuf2 / idper , idsno , idsst 
      common / ncstuf2 / idyce , idsnrf
