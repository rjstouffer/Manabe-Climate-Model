      parameter (maxcpu = iy)
c
c  maxcpu is the maximum number of used cpus
