c
      common / cabd   / cca(lx,2), ccb(lx,2), st(2)
