      common / intgrl / zmdrag(il), drvor, zmcnvr(il), cnvr
      common / intgrl / zmpc  (il), tprec, zmsn  (il), tsnow
      common / intgrl / zmrn  (il), train, zmt   (il), zmts
      common / intgrl / zmevap(il), tevap, zmhtfx(il), thtfx
      common / intgrl / zmvdis(il), tvdis, zmu3  (il), zmt9(il)
      common / intgrl / zmvfr (il), cmvfr, gvfr
      common / intgrl / zmadj (il), gmadj, zmvft (il), gvft
      common / intgrl / zmcah (il), caht
