cSGI
      real*4 zsvar
cSGI
      common / zsrvar / zsvar(ix,il), rk0
