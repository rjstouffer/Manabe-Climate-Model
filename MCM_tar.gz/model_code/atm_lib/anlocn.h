      common / anlocn / somto, somyce, somqao, somsno
