      common / rdintl / sdtop, rutop, sdbtm, rubtm, gsgrad
