      common / h2olw  / aod(nb), sod(nb), apa(nb,2), bpb(nb,2)
