      common / anal2  / samta,samsw,samlw,samto,samyce,samqao,samsno
#if defined cpldleg3 || defined cpldleg1
      common / anal2  / sampme
#endif
