      common / gridw  / gwdot(ix,kp)
