#ifdef garratt
      common / richrd / ri(ix,km), rib(ix)
      common / richrd / stbadj(ix)
#endif
c
c ri(ix,km)    = free atmosphere gradient ricjardson number
c rib(ix)      = bulk richardson number
c stbadj(ix)   = richardson number dependent adjustment to
c                vertical mixing coefficients
