      common / dxordy / psdxm(mx)   , uvdxm(mx,jx), psdym(mx,jx)
      common / dxordy / uvdym(mx,jx), psdyp(mx,jx), uvdyp(mx,jx)
