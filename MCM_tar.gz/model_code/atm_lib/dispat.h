      common / dispat / viscxy, tconxy, qconxy
