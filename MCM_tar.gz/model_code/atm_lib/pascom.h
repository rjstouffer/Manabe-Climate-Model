      common / psacom  / anlwrd(awrds,il)
c
c  anlwrd is the data to be written out to unit 30
c         It is written outside of the jrow-slabbed
c         multitasked region.
