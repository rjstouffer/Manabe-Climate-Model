      common / swtabl / aaa(2000), aab(1000)
