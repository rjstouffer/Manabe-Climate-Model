c
      parameter ( jx=jtrun + 2, mx=mtrun + 1)
      parameter ( jxp=jx + 1, mxp=isc*mtrun + 1)
c
