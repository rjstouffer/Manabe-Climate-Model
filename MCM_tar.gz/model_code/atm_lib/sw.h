      common / sw     / sec, adir(k2,ngp), aref(k2,lx,ngp)
