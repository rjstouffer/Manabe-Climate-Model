      common / psbcom  / anlwrd(bwrds,il)
c
c  anlwrd is the data to be written out to unit 31
c         It is written outside of the jrow-slabbed
c         multitasked region.
