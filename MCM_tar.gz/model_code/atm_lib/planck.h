      common / planck / tdegk(ix,0:kp), tcube(ix,0:kp)
      common / planck / pbb  (ix,0:kp), dpbb (ix,0:kx)
