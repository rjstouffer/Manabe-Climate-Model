cSGI matrix chg to matrxa to avoid conflict with ocean routine.
      common / matrxa / divmtx(lpmx,kx,kx), pmatrx(kx,kx), dbrcof(kx)
      common / matrxa / acof1(kx), acof2 (kx), acof3 (kx), acof4(kx)
      common / matrxa / acof5(kx), acof6 (kx), acof7 (kx), acof8(kx)
      common / matrxa / acof9(kx), acof10(kx), acof11(kx)
      common / matrxa / bcof1(kx), bcof2 (kx), bcof3 (kx), bcof4(kx)
      common / matrxa / bcof5(kx), bcof6 (kx), bcof7 (kx), bcof8(kx)
      common / matrxa / bcof9(kx), bcof10(kx), bcof11(kx)
      common / matrxa / tcof1(kx), tcof2 (kx), tcof3 (kx), dstpin
