      common / cld1   / ca(lx), cb(lx), cosz, sng, solarc, solc, tauda
