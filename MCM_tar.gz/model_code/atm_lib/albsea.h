      common / albsea / oas(19)
