      common / co2lw  / alogab(30,12), alogdt(7,12)
