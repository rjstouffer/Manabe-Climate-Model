c
      common / cloudcx / kfgcov(ix,il)
c
c  kfgcov contains the convective flag bits, packed with height.
c
