      common / sfharm / vor (mx,jx,kx), div (mx,jx,kx), ucos(mx,jx,kx)
      common / sfharm / vcos(mx,jx,kx),  t  (mx,jx,kx), psdx(mx,jx, 1)
      common / sfharm / psdy(mx,jx, 1), psln(mx,jx, 1),  zs (mx,jx, 1)
