      common / lats   / ylat(il)
c
c  ylat = latitudes in degrees (ylat(1) is nearest to the North pole)
