      common / onlint / psbare, tbare, tke , am   , angm
      common / onlint / enthl , ekpot, eke , zeke , divv
      common / onlint / entr  , qbare, drag, cnver, dissp
      common / onlint / trq2  , trqt , znke, eddy
