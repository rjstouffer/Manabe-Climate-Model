c
      parameter ( ncc=4 )
      parameter ( nc=ncc + 1 )
c
c nc = the number of clouds in the simulation
c ncc = nc + one dummy cloud
c
