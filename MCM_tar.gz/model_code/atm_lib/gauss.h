      common / gauss  / coa   (iy), weight(iy), sia(iy)
      common / gauss  / radang(iy), cosqr (iy)
