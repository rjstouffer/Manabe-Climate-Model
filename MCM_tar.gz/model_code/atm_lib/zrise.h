      logical grow
c
      common / zrise / rzs(mx,jx,1),grow
