#ifdef impcit
      common / wimplt / tmean(kx), tmnshr(kp), gwexpt(ix,kp)
#endif
