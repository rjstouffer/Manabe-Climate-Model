#ifdef rad
      common / radten1 / radten(mx,jx,kx)
#endif
