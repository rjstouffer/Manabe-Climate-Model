c
      parameter ( mx2=2*mx, mx4=4*mx )
      parameter ( mxjx=mx*jx, mxjx2=2*mxjx )
      common / clnpol / colyl(mx2,jx), colydx(mxjx2), colydy(mxjx2)
c
