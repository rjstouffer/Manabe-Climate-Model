      common / swnuin / cwca(k2), cwcb(k2), coca(k2), cloudy(k2)
      common / swnuin / kthsw(k2), kbhsw(k2)
      common / swnuin / solrsw, pr2(kp)
      common / swnuin / nc0, nc1, nc2, nc3, nc4
