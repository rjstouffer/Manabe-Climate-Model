c
      parameter (leng=ix*kx)
      parameter (lengm=ix*km)
c
