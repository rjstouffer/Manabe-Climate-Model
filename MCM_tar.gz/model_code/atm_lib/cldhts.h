c
      common / cldhts / cldhm, cldml
c
c  cldhm is the boundary in sigma units between hi and middle clouds
c  cldml is the boundary in sigma units between middle and lo clouds
c
