      logical la, lo
c
      common / asblck / la, lo
c
c la is true the first time into the atmospheric code,
c    it is false for the rest of the model integration.
c lo is true the first time into the oceanic code,
c    it is false for the rest of the model integration.
